﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Web;
using System.Net;
using System.Windows.Forms;
using System.Web.Script.Serialization;
namespace DEMO2
{
    public partial class demo2 : Form
    {
        public demo2()
        {
            InitializeComponent();
        }

        public string session = "";

        private void productAddContract(string ord)
        {

            // 将产品列表的产品 添加入合同明细
            string json = "{session:\"" + session + "\",cmdkey:\"addToContract\",datas:[";
            json += "{id:\"ord\", val:\""+ ord +"\"},";		//数据唯一标识
            json += "{id:\"company\", val:\"0\"}";		//
            json = json + "]}";
            byte[] data = Encoding.UTF8.GetBytes(json);
            string url = "http://127.0.0.1:908/mobilephone/salesmanage/contract/contractlist.asp";
            WebClient webClient = new WebClient();
            //接口规定content-type值必须为application/zsml。
            //注：采用utf-8编码标记，服务器会按utf-8编码接收数据，按utf-8编码返回数据。
            webClient.Headers.Add("Content-Type", "application/zsml; charset=utf-8");
            byte[] responseData = webClient.UploadData(url, "POST", data);
            string result = Encoding.UTF8.GetString(responseData);
            //MessageBox.Show(result);	//输出返回结果
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                document doc = ser.Deserialize<document>(result);
                //MessageBox.Show(doc.body.action); 
                if (doc.body.model != "message")
                {
                    MessageBox.Show(doc.header.message);
                }
                else
                {
                    //通过返回结果的Bill结构value属性为新的ID
                    MessageBox.Show("产品" + ord + " " + doc.body.message.text);
                }

            }
            catch (Exception x)
            {
                MessageBox.Show(result);
            }
        }

        public void getListView()
        {
            //获取订单(合同)列表信息 可以为订单详情提供必要的ID
            string json = "{session:\"" + session + "\",cmdkey:\"refresh\", datas:[";
            json += "{id:\"stype\", val:\"0\"},";		//合同列表类型 0 所有列表 1 待审批合同 2 即将到期合同
            json += "{id:\"pagesize\", val:\"10\"},";		//每页记录数
            json += "{id:\"pageindex\", val:\"1\"},";		//数据页标
            json += "{id:\"_rpt_sort\", val:\"-1\"}";		//排序字段
            json = json + "]}";
            byte[] data = Encoding.UTF8.GetBytes(json);
            string url = "http://127.0.0.1:908/mobilephone/salesmanage/contract/billlist.asp";
            WebClient webClient = new WebClient();
            //接口规定content-type值必须为application/zsml。
            //注：采用utf-8编码标记，服务器会按utf-8编码接收数据，按utf-8编码返回数据。
            webClient.Headers.Add("Content-Type", "application/zsml; charset=utf-8");
            byte[] responseData = webClient.UploadData(url, "POST", data);
            string result = Encoding.UTF8.GetString(responseData);

            //MessageBox.Show(result);	//输出返回结果
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                document doc = ser.Deserialize<document>(result);
                //MessageBox.Show(doc.body.action); 
                if (doc.body.model != "source")
                {
                    MessageBox.Show(doc.header.message);
                    return;
                }
                else
                {
                    table t = doc.body.source.table;
                    List<List<object>> s = t.rows;
                    List<col> cols = t.cols;
                    for (int i = 0; i < 10; i++)
                    {
                        List<object> l = s[i];
                        ListViewItem lvi = new ListViewItem();
                        for (int ii = 0; ii < l.Count; ii++)
                        {
                            if (i == 0)
                            {
                                listView1.Columns.Add(cols[ii].id.ToString());
                            }
                            if (ii > 0)
                            {
                                lvi.SubItems.Add(l[ii].ToString());
                            }
                            else
                            {
                                lvi.Text = l[ii].ToString();
                            }

                        }
                        listView1.Items.Add(lvi);
                    }
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message);
                return;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //接口登录
            string json = "{session:\"******\", datas:[";
            json += "{id:\"user\", val:\"txt:admin\"},";		//用户名
            json += "{id:\"password\", val:\"txt:88888888\"},";		//用户名密码
            json += "{id:\"serialnum\", val:\"txt:35237005413511\"},";		//设备串号 该值和设置相关 可在账号设置有启用移动端,绑定手机串号 只有对应上就可以
            json += "{id:\"rndcode\", val:\"\"}";		//随机验证码
            json = json + "]}";
            byte[] data = Encoding.UTF8.GetBytes(json);
            string url = "http://127.0.0.1:908/mobilephone/login.asp";
            WebClient webClient = new WebClient();
            //接口规定content-type值必须为application/zsml。
            //注：采用utf-8编码标记，服务器会按utf-8编码接收数据，按utf-8编码返回数据。
            webClient.Headers.Add("Content-Type", "application/zsml; charset=utf-8");
            byte[] responseData = webClient.UploadData(url, "POST", data);
            string result = Encoding.UTF8.GetString(responseData);
            // MessageBox.Show(result);	//输出返回结果
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                document doc = ser.Deserialize<document>(result);
                //MessageBox.Show(doc.body.action);
                if (doc.body.action != "sys")
                {
                    MessageBox.Show("接口登录失败,请联系管理员!");
                }
                else
                {
                    MessageBox.Show("恭喜您,接口登录成功!");
                    session = doc.header.session;
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(result);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //添加合同明细 产品ID 64071 ,64394
            productAddContract("64071");
            productAddContract("64394");
            //添加新的订单(合同)
            string json = "{session:\"" + session + "\",cmdkey:\"__sys_dosave\", datas:[";
            json += "{id:\"ord\", val:\"\"},";		//数据唯一标识  添加时为空
            json += "{id:\"company\", val:\"234639\"},";		//关联客户 必须是正确的客户ID 可以通过接口 合同关联客户接口调取
            json += "{id:\"htid\", val:\"HT_20151026001\"},";		//合同编号
            json += "{id:\"title\", val:\"合同主题\"},";		//合同主题
            json += "{id:\"date3\", val:\"2015-10-26\"},";		//签订日期
            json += "{id:\"date1\", val:\"2015-10-26\"},";		//开始日期
            json += "{id:\"date2\", val:\"2016-10-25\"},";		//结束日期
            json += "{id:\"person2id\", val:\"0\"},";		//对方代表
            json += "{id:\"sort\", val:\"192\"},";		//合同分类
            json += "{id:\"complete1\", val:\"195\"},";		//合同状态
            json += "{id:\"bz\", val:\"14\"},";		//币　　种
            json += "{id:\"premoney\", val:\"0.000\"},";		//合同总额
            json += "{id:\"yhtype\", val:\"0\"},";		//优惠方式
            json += "{id:\"money1\", val:\"0.000\"},";		//优惠后总额
            json += "{id:\"fqhk\", val:\"0\"},";		//回款计划
            json += "{id:\"paybackMode\", val:\"1\"},";		//收款类型
            json += "{id:\"invoicePlan\", val:\"1\"},";		//开票计划
            json += "{id:\"invoiceMode\", val:\"0\"},";		//开票类型
            json += "{id:\"extras\", val:\"0\"},";		//运杂费
            json += "{id:\"jh_intro3\", val:\"......\"},";		//付款方式
            json += "{id:\"jh_intro4\", val:\"......\"},";		//交货地址
            json += "{id:\"jh_intro5\", val:\"......\"},";		//交货方式
            json += "{id:\"jh_intro6\", val:\"......\"},";		//交货时间
            json += "{id:\"jh_intro1\", val:\"......\"},";		//配件
            json += "{id:\"jh_intro2\", val:\"......\"},";		//备注
            json += "{id:\"yh_money\", val:\"0.000\"},";		//优惠金额
            json += "{id:\"yh_zk\", val:\"1.00\"},";		//折扣
            json += "{id:\"invoicePlanType\", val:\"204\"},";		//票据类型
            json += "{id:\"zdy1\", val:\"......\"},";		//自定义1
            json += "{id:\"zdy2\", val:\"......\"},";		//自定义2
            json += "{id:\"zdy3\", val:\"......\"},";		//自定义3
            json += "{id:\"zdy4\", val:\"......\"},";		//自定义4
            json += "{id:\"zdy5\", val:\"528\"},";		//自定义5
            json += "{id:\"zdy6\", val:\"529\"},";		//自定义6
            json += "{id:\"intro\", val:\"......\"},";		//合同概要
            json += "{id:\"chance\", val:\"0\"}";		//关联项目
            json = json + "]}";
            byte[] data = Encoding.UTF8.GetBytes(json);
            string url = "http://127.0.0.1:908/mobilephone/salesmanage/contract/add.asp";
            WebClient webClient = new WebClient();
            //接口规定content-type值必须为application/zsml。
            //注：采用utf-8编码标记，服务器会按utf-8编码接收数据，按utf-8编码返回数据。
            webClient.Headers.Add("Content-Type", "application/zsml; charset=utf-8");
            byte[] responseData = webClient.UploadData(url, "POST", data);
            string result = Encoding.UTF8.GetString(responseData);
            //MessageBox.Show(result);	//输出返回结果
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                document doc = ser.Deserialize<document>(result);
                //MessageBox.Show(doc.body.action); 
                if (doc.body.model != "message")
                {
                    MessageBox.Show(doc.header.message);
                }
                else
                {
                    //提示返回结果信息
                    MessageBox.Show("合同 "+doc.body.message.text);
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(result);
                return;
            }
            getListView();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //退出登录 可以为本次接口调用释放系统资源 
            string json = "{ session: \"" + session + "\" } "; //本接口只需附加上会话凭证即可，没有额外参数。
            byte[] data = Encoding.UTF8.GetBytes(json);
            string url = "http://127.0.0.1:908/mobilephone/logout.asp";
            WebClient webClient = new WebClient();
            //接口规定content-type值必须为application/zsml。
            //注：采用utf-8编码标记，服务器会按utf-8编码接收数据，按utf-8编码返回数据。
            webClient.Headers.Add("Content-Type", "application/zsml; charset=utf-8");
            byte[] responseData = webClient.UploadData(url, "POST", data);
            string result = Encoding.UTF8.GetString(responseData);
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                document doc = ser.Deserialize<document>(result);
                //MessageBox.Show(doc.body.action);
                MessageBox.Show("谢谢您的使用,已成功退出登录!");
                session = "";
            }
            catch (Exception x)
            {
                MessageBox.Show(result);
            }
        }
    }



    public class document
    {
        public header header { get; set; }
        public body body { get; set; }
    }

    public class header
    {
        public int status { get; set; }
        public string message { get; set; }
        public string language { get; set; }
        public string session { get; set; }
    }

    public class body
    {
        public string action { get; set; }
        public string model { get; set; }
        public bill bill { get; set; }
        public sourceClass source { get; set; }
        public messageClass message { get; set; }
    }

    public class messageClass
    {
        public string text { get; set; }
    }

    public class bill
    {
        public int value { get; set; }
    }

    public class sourceClass
    {
        public table table { get; set; }
    }

    public class table
    {
        public List<col> cols { get; set; }
        public List<List<object>> rows { get; set; }
    }

    public class col
    {
        public string id { get; set; }
    }

}
