﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Web;
using System.Net;
using System.Windows.Forms;
using System.Web.Script.Serialization;
namespace DEMO
{
    public partial class demo : Form
    {
        public demo()
        {
            InitializeComponent();
        }

        public string session = "";

        private void button1_Click(object sender, EventArgs e)
        {
            //接口登录
            string json = "{session:\"******\", datas:[";
            json += "{id:\"user\", val:\"txt:admin\"},";		//用户名
            json += "{id:\"password\", val:\"txt:88888888\"},";		//用户名密码
            json += "{id:\"serialnum\", val:\"txt:35237005413511\"},";		//设备串号 该值和设置相关 可在账号设置有启用移动端,绑定手机串号 只有对应上就可以
            json += "{id:\"rndcode\", val:\"\"}";		//随机验证码
            json = json + "]}";
            byte[] data = Encoding.UTF8.GetBytes(json);
            string url = "http://127.0.0.1:908/mobilephone/login.asp";
            WebClient webClient = new WebClient();
            //接口规定content-type值必须为application/zsml。
            //注：采用utf-8编码标记，服务器会按utf-8编码接收数据，按utf-8编码返回数据。
            webClient.Headers.Add("Content-Type", "application/zsml; charset=utf-8");
            byte[] responseData = webClient.UploadData(url, "POST", data);
            string result = Encoding.UTF8.GetString(responseData);
           // MessageBox.Show(result);	//输出返回结果
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                document doc = ser.Deserialize<document>(result);
                //MessageBox.Show(doc.body.action);
                if (doc.body.action != "sys")
                {
                    MessageBox.Show("接口登录失败,请联系管理员!");
                }
                else
                {
                    MessageBox.Show("恭喜您,接口登录成功!");
                    session = doc.header.session;
                }
            }
            catch (Exception x) {
                MessageBox.Show(result);
            }
        }

        private string getnewId() {

            // 分配新客户ID 添加客户之前必须要给客户分配新的ID
            string json = "{session:\"" + session + "\", datas:[";
            json += "{id:\"edit\", val:\"0\"},";		//修改模式
            json += "{id:\"intsort\", val:\"1\"},";		//客户类型
            json += "{id:\"ord\", val:\"0\"},";		//数据唯一标识
            json += "{id:\"datatype\", val:\"......\"}";		//
            json = json + "]}";
            byte[] data = Encoding.UTF8.GetBytes(json);
            string url = "http://127.0.0.1:908/mobilephone/salesmanage/custom/add.asp";
            WebClient webClient = new WebClient();
            //接口规定content-type值必须为application/zsml。
            //注：采用utf-8编码标记，服务器会按utf-8编码接收数据，按utf-8编码返回数据。
            webClient.Headers.Add("Content-Type", "application/zsml; charset=utf-8");
            byte[] responseData = webClient.UploadData(url, "POST", data);
            string result = Encoding.UTF8.GetString(responseData);
            //MessageBox.Show(result);	//输出返回结果
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                document doc = ser.Deserialize<document>(result);
                //MessageBox.Show(doc.body.action); 
                if (doc.body.model != "bill")
                {
                    MessageBox.Show(doc.header.message);
                    return "";
                }
                else {
                    //通过返回结果的Bill结构value属性为新的ID
                    return doc.body.bill.value.ToString();
                }
 
            }
            catch (Exception x)
            {
                MessageBox.Show(result);
                return "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            string ord = getnewId();
            if (ord.Length == 0) { return; }
            //添加新的客户
            string json = "{session:\"" + session + "\",cmdkey:\"__sys_dosave\", datas:[";
            json += "{id:\"ord\", val:\""+ ord +"\"},";		//数据唯一标识
            json += "{id:\"name\", val:\"......\"},";		//客户名称
            json += "{id:\"pym\", val:\"......\"},";		//拼 音 码
            json += "{id:\"khid\", val:\"KH_15102401\"},";		//客户编号
            json += "{id:\"sort1\", val:\"17,146\"},";		//客户分类,跟进程度
            json += "{id:\"ly\", val:\"173\"},";		//客户来源
            json += "{id:\"jf2\", val:\"1\"},";		//是否积分
            json += "{id:\"area\", val:\"219\"},";		//客户区域
            json += "{id:\"trade\", val:\"139\"},";		//客户行业
            json += "{id:\"jz\", val:\"175\"},";		//价值评估
            json += "{id:\"credit\", val:\"496\"},";		//信用等级
            json += "{id:\"url\", val:\"http://\"},";		//客户网址
            json += "{id:\"hk_xz\", val:\"......\"},";		//到款限制
            json += "{id:\"address\", val:\"......\"},";		//客户地址
            json += "{id:\"zip\", val:\"......\"},";		// 邮  编 
            json += "{id:\"faren\", val:\"......\"},";		//法人代表
            json += "{id:\"zijin\", val:\"......\"},";		//注册资本
            json += "{id:\"pernum1\", val:\"......\"},";		//人员数量-销售
            json += "{id:\"pernum2\", val:\"......\"},";		//人员数量-技术
            json += "{id:\"zdy1\", val:\"......\"},";		//自定义1
            json += "{id:\"zdy3\", val:\"......\"},";		//自定义3
            json += "{id:\"zdy4\", val:\"......\"},";		//自定义4
            json += "{id:\"zdy5\", val:\"527\"},";		//自定义5
            json += "{id:\"zdy6\", val:\"415\"},";		//自定义6
            json += "{id:\"@Numr_10\", val:\"......\"},";		//数字格式
            json += "{id:\"@danh_18\", val:\"......\"},";		//谔谔
            json += "{id:\"@meju_19\", val:\"4\"},";		//职称
            json += "{id:\"@danh_20\", val:\"......\"},";		//阿斯蒂芬
            json += "{id:\"@IsNot_7\", val:\"是\"},";		//是否
            json += "{id:\"@beiz_8\", val:\"......\"},";		//多行文本
            json += "{id:\"@date_9\", val:\"......\"},";		//日期格式
            json += "{id:\"person_name\", val:\"......\"},";		//联系人姓名
            json += "{id:\"@personpym\", val:\"......\"},";		//
            json += "{id:\"sex\", val:\"男\"},";		// 性  别 
            json += "{id:\"age\", val:\"......\"},";		// 年  龄 
            json += "{id:\"year1\", val:\"......\"},";		// 生  日 
            json += "{id:\"part1\", val:\"......\"},";		// 部  门 
            json += "{id:\"job\", val:\"......\"},";		// 职  务 
            json += "{id:\"fax\", val:\"......\"},";		// 传  真 
            json += "{id:\"mobile\", val:\"......\"},";		// 手  机 
            json += "{id:\"phone2\", val:\"......\"},";		//家庭电话
            json += "{id:\"email\", val:\"......\"},";		//电子邮件
            json += "{id:\"qq\", val:\"......\"},";		//   QQ   
            json += "{id:\"weixinAcc\", val:\"......\"},";		//微  信
            json += "{id:\"msn\", val:\"......\"},";		//   MSN  
            json += "{id:\"jg\", val:\"......\"},";		// 籍  贯 
            json += "{id:\"product\", val:\"......\"},";		//客户简介
            json += "{id:\"c2\", val:\"......\"},";		//合作现状
            json += "{id:\"c3\", val:\"......\"},";		//合作前景
            json += "{id:\"c4\", val:\"......\"},";		//跟进策略
            json += "{id:\"intro\", val:\"......\"},";		// 备  注 
            json += "{id:\"bank_1\", val:\"......\"},";		//开户银行1
            json += "{id:\"bank_2\", val:\"......\"},";		//开户名称1
            json += "{id:\"bank_7\", val:\"......\"},";		//银行行号1
            json += "{id:\"bank_3\", val:\"......\"},";		//银行账号1
            json += "{id:\"bank_4\", val:\"......\"},";		//税号1
            json += "{id:\"bank_5\", val:\"......\"},";		//地址1
            json += "{id:\"bank_6\", val:\"......\"},";		//电话1
            json += "{id:\"bank2_1\", val:\"......\"},";		//开户银行2
            json += "{id:\"bank2_2\", val:\"......\"},";		//开户名称2
            json += "{id:\"bank2_7\", val:\"......\"},";		//银行行号2
            json += "{id:\"bank2_3\", val:\"......\"},";		//银行账号2
            json += "{id:\"bank2_4\", val:\"......\"},";		//税号2
            json += "{id:\"bank2_5\", val:\"......\"},";		//地址2
            json += "{id:\"bank2_6\", val:\"......\"}";		//电话2
            json = json + "]}";
            byte[] data = Encoding.UTF8.GetBytes(json);
            string url = "http://127.0.0.1:908/mobilephone/salesmanage/custom/add.asp";
            WebClient webClient = new WebClient();
            //接口规定content-type值必须为application/zsml。
            //注：采用utf-8编码标记，服务器会按utf-8编码接收数据，按utf-8编码返回数据。
            webClient.Headers.Add("Content-Type", "application/zsml; charset=utf-8");
            byte[] responseData = webClient.UploadData(url, "POST", data);
            string result = Encoding.UTF8.GetString(responseData);
            //MessageBox.Show(result);	//输出返回结果
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                document doc = ser.Deserialize<document>(result);
                //MessageBox.Show(doc.body.action); 
                if (doc.body.model != "message")
                {
                    MessageBox.Show(doc.header.message);
                }
                else
                {
                    //提示返回结果信息
                    MessageBox.Show(doc.body.message.text);
                }
            }
            catch (Exception x) {
                MessageBox.Show(result);
                return;
            }
            getListView();

        }

        public void getListView() {
            //获取客户列表信息 可以为客户详情提供必要的ID
            string json = "{session:\""+ session +"\",cmdkey:\"refresh\", datas:[";
            json += "{id:\"searchKey\", val:\"\"},";		//快速检索条件
            json += "{id:\"pagesize\", val:\"10\"},";		//每页记录数
            json += "{id:\"pageindex\", val:\"1\"},";		//数据页标
            json += "{id:\"_rpt_sort\", val:\"-1\"}";		//排序字段 按添加时间倒序排序
            json = json + "]}";
            byte[] data = Encoding.UTF8.GetBytes(json);
            string url = "http://127.0.0.1:908/mobilephone/salesmanage/custom/list.asp";
            WebClient webClient = new WebClient();
            //接口规定content-type值必须为application/zsml。
            //注：采用utf-8编码标记，服务器会按utf-8编码接收数据，按utf-8编码返回数据。
            webClient.Headers.Add("Content-Type", "application/zsml; charset=utf-8");
            byte[] responseData = webClient.UploadData(url, "POST", data);
            string result = Encoding.UTF8.GetString(responseData);
            //MessageBox.Show(result);	//输出返回结果
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                document doc = ser.Deserialize<document>(result);
                //MessageBox.Show(doc.body.action); 
                if (doc.body.model != "source")
                {
                    MessageBox.Show(doc.header.message);
                    return;
                }
                else
                {
                    table t = doc.body.source.table;
                    List<List<object>> s = t.rows;
                    List<col> cols = t.cols;
                    for (int i = 0; i < 10; i ++ )
                    {
                        List<object> l = s[i];
                        ListViewItem lvi = new ListViewItem();
                        for (int ii = 0; ii < l.Count; ii++) {
                            if (i == 0) {
                                listView1.Columns.Add(cols[ii].id.ToString());
                            }
                            if (ii > 0)
                            {
                                lvi.SubItems.Add(l[ii].ToString());
                            }
                            else {
                                lvi.Text = l[ii].ToString();
                            }

                        }
                        listView1.Items.Add(lvi);
                    }
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message);
                return;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //退出登录 可以为本次接口调用释放系统资源 
            string json = "{ session: \""+ session +"\" } "; //本接口只需附加上会话凭证即可，没有额外参数。
            byte[] data = Encoding.UTF8.GetBytes(json);
            string url = "http://127.0.0.1:908/mobilephone/logout.asp";
            WebClient webClient = new WebClient();
            //接口规定content-type值必须为application/zsml。
            //注：采用utf-8编码标记，服务器会按utf-8编码接收数据，按utf-8编码返回数据。
            webClient.Headers.Add("Content-Type", "application/zsml; charset=utf-8");
            byte[] responseData = webClient.UploadData(url, "POST", data);
            string result = Encoding.UTF8.GetString(responseData);
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                document doc = ser.Deserialize<document>(result);
                //MessageBox.Show(doc.body.action);
                MessageBox.Show("谢谢您的使用,已成功退出登录!");
                session = "";
            }
            catch (Exception x)
            {
                MessageBox.Show(result);
            }
        }
    }



    public class document
    {
        public header header { get; set; }
        public body body { get; set; }
    }

    public class header
    {
        public int status {get; set;}
        public string message {get; set;}
        public string language {get; set;}
        public string session { get; set; }
    }

    public class body
    {
        public string  action  { get; set; }
        public string  model { get; set; }
        public bill bill { get; set; }
        public sourceClass source { get; set; }
        public messageClass message { get; set; }
    }

    public class messageClass
    {
        public string text { get; set; }
    }

    public class bill {
        public int value { get; set; }
    }

    public class sourceClass
    {
        public table table { get; set; } 
    }

    public class table
    {
        public List<col> cols { get; set; } 
        public List<List<object>> rows { get; set; } 
    }

    public class col
    {
        public string id { get; set; }
    }

}
